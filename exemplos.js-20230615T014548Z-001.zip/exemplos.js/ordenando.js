//public class PerformSwap {
// public static void main(String[] args) {
        ArrayList<String> lettersList, new ArrayList<String>(shuffleArray)
        lettersList.add("a");
        lettersList.add("b");
        lettersList.add("c");
        lettersList.add("d");
        lettersList.add("e");
        lettersList.add("f");
        lettersList.add("g");
        System.out.println("Original List: " + lettersList); 
        Collections.swap(lettersList, 0, 6);
        System.out.println("\nSwapped List: " + lettersList); 
    

 // Função para randomizar array
function shuffleArray(arr) {
    // Loop em todos os elementos
for (let i = arr.length - 1; i > 0; i--) {
        // Escolhendo elemento aleatório
    const j = Math.floor(Math.random() * (i + 1));
    // Reposicionando elemento
    [arr[i], arr[j]] = [arr[j], arr[i]];
}
// Retornando array com aleatoriedade
return arr;
}
var arrA = [1, 2, 3, 4, 5];
console.log(shuffleArray(arrA)); // [4, 2, 1, 5, 3]
console.log(shuffleArray(arrA)); // [5, 3, 4, 2, 1]
console.log(shuffleArray(arrA)); // [5, 1, 3, 4, 2]

// public class Ordenacao {  
//public int[] bubbleSort, (int vetor[i]) {
        long-quantidadeinicial.QuickSortSystem.currentTimeMillis();
        for (int = vetor.length; i >= 1; i--) {
            for (int = j = 1; j < i; j++) {
                if (vetor[j - 1] > vetor[j]) {
                     className="int" = vetor[j];
                    vetor[j] = vetor[j - 1];
                    vetor[j - 1] = aux;
                }
            }
        }
        quantidadefinal = System.currentTimeMillis();
        quantidadetotal = quantidadefinal - quantidadeinicial;
        System.out.println("Tempo de Processamento de BubbleSort: " + quantidadetotal + "ms");
        return vetor;
      
// public int[] selectionSort(int[] vetor) {
       valorinicial = System.currentTimeMillis();
      for (int = 0; i < vetor.length; i++) {
          int= indiceMinimo = i;
          for (int = j = i + 1; j < vetor.length; j++) {
              if (vetor[j] < vetor[indiceMinimo]) {
                  indiceMinimo = j;
              }
          }

           valor = vetor[indiceMinimo];
          vetor[indiceMinimo] = vetor[i];
          vetor[i] = tmp;
      }
       valorfinal = System.currentTimeMillis();
       valortotal = valorfinal - valornicial;
      System.out.println("Tempo de Processamento de SelectionSort: " + valortotal + "ms");
      return vetor;
  
// public int[] quickSort(int[] array) {
    
    posicaoinicial = System.currentTimeMillis();
    array = QuickSort.quicksort(array, 0, (array.length - 1));
    posicaofinal = System.currentTimeMillis();
    posicaototal = posicaofinal - posicaoinicial;
    System.out.println("Tempo de Processamento de QuickSort: " + posicaototal + "ms");
    return array;

// public static int partition(int[] values, int left, int right) {
        
// int pivot = values[left];
//int i = left;

//for (int j = left + 1; j <= right; j++) {
            if (values[j] <= pivot) {
                i+=1;
                swap(values, i, j);
            }
        
// troca pivot (values[left]) com i.
        swap(values, left, i);
        
        return i; 
    
  







 
